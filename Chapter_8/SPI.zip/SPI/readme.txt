Project Name:	SPI

Vivado version: 2014.4

Description:
  This is a Project of SPI Master. 
  A testbench is included which will have the Master generate data for sending.